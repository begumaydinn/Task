EXEC CalculateExchangeRate;

DROP PROCEDURE dbo.CalculateExchangeRate; 
